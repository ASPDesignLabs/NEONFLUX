package com.snakesan.neonflux

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.*
import android.util.Log
import com.google.android.gms.wearable.MessageClient
import com.google.android.gms.wearable.MessageEvent
import com.google.android.gms.wearable.PutDataMapRequest
import com.google.android.gms.wearable.Wearable
import kotlinx.coroutines.*
import java.nio.ByteBuffer
import kotlin.random.Random

data class SequencerStep(val state: Int, val overrideIntensity: Int)

class FluxService : Service(), MessageClient.OnMessageReceivedListener {

    private val scope = CoroutineScope(Dispatchers.Default + Job())
    private lateinit var synth: SynthEngine
    private lateinit var vibrator: Vibrator
    private var wakeLock: PowerManager.WakeLock? = null

    private fun startEmergencyOverride(intensity: Float, durationMin: Int) {
        clinicalJob?.cancel()
        isRunning = true
        activeProfile = -1 // Signifies Override
        synth.stop()

        val durationStr = if (durationMin > 0) "${durationMin}M" else "INF"
        updateState("EMERGENCY [$durationStr]")

        clinicalJob = scope.launch {
            // Convert the 0-100f intensity to a 0-255 amplitude
            val amp = (intensity / 100f * 255).toInt().coerceIn(10, 255)

            // Issue a single, infinitely repeating waveform command
            if (vibrator.hasAmplitudeControl()) {
                val timings = longArrayOf(2000)
                val amplitudes = intArrayOf(amp)
                // The '0' repeat index loops the pattern from the beginning infinitely
                vibrator.vibrate(VibrationEffect.createWaveform(timings, amplitudes, 0))
            } else {
                val timings = longArrayOf(0, 2000)
                // Alternate between off/on if no amplitude control, though 0 delay means instantly on
                vibrator.vibrate(VibrationEffect.createWaveform(timings, 0))
            }

            // Let it run until the timer expires (or wait forever if indefinite)
            if (durationMin > 0) {
                delay(durationMin * 60 * 1000L)
                haltLoops() // Timer expired, shut it down
            } else {
                // Suspend indefinitely until standard haltLoops() is called by the UI
                awaitCancellation()
            }
        }
    }

    // Engine State
    private var isRunning = false
    var currentMode = "STANDBY"
    private var activeProfile = 0
    private var clinicalJob: Job? = null

    // 2. THIS WILL NOW COMPILE PERFECTLY:
    private var customSequence: List<SequencerStep> = emptyList()
    
    private val binder = LocalBinder()
    
    inner class LocalBinder : Binder() {
        fun getService(): FluxService = this@FluxService
    }

    // --- OVERSEER KILL SWITCH ---
    private val killReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == "com.snakesan.overseer.KILL_COMMAND") {
                Log.w("FluxService", "OVERSEER KILL COMMAND RECEIVED. TERMINATING.")
                haltService()
            }
        }
    }

    override fun onBind(intent: Intent): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        synth = SynthEngine()
        
        // Init Vibrator
        vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }

        // Init WakeLock (Safety net for Silent Mode)
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "NeonFlux:CoreLock")
        
        // Listen to Phone
        Wearable.getMessageClient(this).addListener(this)
        
        // Register Kill Switch
        val filter = IntentFilter("com.snakesan.overseer.KILL_COMMAND")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(killReceiver, filter, Context.RECEIVER_EXPORTED)
        } else {
            registerReceiver(killReceiver, filter)
        }
        
        createNotificationChannel()
    }
    
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP_SERVICE") {
            haltService()
            return START_NOT_STICKY
        }

        // Promote to Foreground (Media Playback type for Android 14+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(99, createNotification("NeonFlux Engine Active"), 
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(99, createNotification("NeonFlux Engine Active"))
        }
        
        // Acquire lock if not held
        if (wakeLock?.isHeld == false) wakeLock?.acquire(24 * 60 * 60 * 1000L) // 24hr timeout
        
        return START_STICKY
    }

    // --- PHONE COMMUNICATION HANDLER ---
    override fun onMessageReceived(event: MessageEvent) {

        // CASE 1: JUST SYNC SETTINGS (DO NOT START)
        if (event.path == "/clinical_conf") {
            try {
                val buffer = ByteBuffer.wrap(event.data)
                val profile = buffer.get().toInt()
                val bpm = buffer.getInt()
                val intensity = buffer.get().toInt()
                val sleep = buffer.get().toInt() == 1

                // NEW: Parse Custom Sequencer Data
                if (profile == 3 && buffer.hasRemaining()) {
                    val totalSteps = buffer.get().toInt()
                    val tempSeq = mutableListOf<SequencerStep>()
                    for (i in 0 until totalSteps) {
                        tempSeq.add(SequencerStep(buffer.get().toInt(), buffer.get().toInt()))
                    }
                    customSequence = tempSeq
                    Log.d("FluxService", "RX Sequencer config: $totalSteps steps loaded.")
                }

                Log.d("FluxService", "RX Config Sync: $bpm BPM")

                activeProfile = profile
                broadcastConfigToUI(profile, bpm, intensity, sleep)
                vibrateAck()

            } catch (e: Exception) { Log.e("FluxService", "Config Error", e) }
        }

        // CASE 2: ENGAGE MOTOR (MIRRORED START)
        else if (event.path == "/clinical_engage") {
            try {
                val buffer = ByteBuffer.wrap(event.data)
                val profile = buffer.get().toInt()
                val bpm = buffer.getInt()
                val intensity = buffer.get().toInt()
                val sleep = buffer.get().toInt() == 1
                val targetTime = buffer.getLong()

                // NEW: Parse Custom Sequencer Data
                if (profile == 3 && buffer.hasRemaining()) {
                    val totalSteps = buffer.get().toInt()
                    val tempSeq = mutableListOf<SequencerStep>()
                    for (i in 0 until totalSteps) {
                        tempSeq.add(SequencerStep(buffer.get().toInt(), buffer.get().toInt()))
                    }
                    customSequence = tempSeq
                    Log.d("FluxService", "RX Sequencer engage: $totalSteps steps loaded.")
                }

                Log.d("FluxService", "RX Engage: Start at $targetTime")

                broadcastConfigToUI(profile, bpm, intensity, sleep)

                synth.stop()
                clinicalJob?.cancel()
                startClinicalWithDelay(bpm, intensity, profile, targetTime)
                vibrateAck()

            } catch (e: Exception) { Log.e("FluxService", "Engage Error", e) }
        }

        // CASE 3: REMOTE STOP
        else if (event.path == "/clinical_stop") {
            haltLoops()
            vibrateAck()
        }

        // CASE 4: THEME SYNC
        else if (event.path == "/flux_theme_sync") {
            try {
                val themeIndex = event.data[0].toInt()
                Log.d("FluxService", "RX Theme Sync: Index $themeIndex")

                val intent = Intent("com.snakesan.neonflux.THEME_SYNC")
                intent.putExtra("theme_index", themeIndex)
                intent.setPackage(packageName)
                sendBroadcast(intent)
            } catch (e: Exception) { Log.e("FluxService", "Theme Sync Error", e) }
        }

        // CASE 5: ACCESSIBILITY SYNC
        else if (event.path == "/flux_a11y_sync") {
            try {
                val buffer = ByteBuffer.wrap(event.data)
                val contrastMode = buffer.get().toInt() == 1
                val fontScale = buffer.getFloat()

                val intent = Intent("com.snakesan.neonflux.A11Y_SYNC")
                intent.putExtra("contrast", contrastMode)
                intent.putExtra("font_scale", fontScale)
                intent.setPackage(packageName)
                sendBroadcast(intent)
            } catch (e: Exception) { Log.e("FluxService", "A11y Sync Error", e) }
        }

        // CASE 6: EMERGENCY OVERRIDE
        else if (event.path == "/emergency_override") {
            try {
                val buffer = ByteBuffer.wrap(event.data)
                val mode = buffer.get().toInt()
                val intensity = buffer.getFloat()
                val durationMin = buffer.getInt()

                Log.d("FluxService", "RX Emergency Protocol: Mode $mode, Int $intensity, Dur $durationMin")

                if (mode == 0) {
                    haltLoops()
                } else {
                    startEmergencyOverride(intensity, durationMin)
                }
                vibrateAck()
            } catch (e: Exception) { Log.e("FluxService", "Emergency Sync Error", e) }
        }
    }



    private fun broadcastConfigToUI(profile: Int, bpm: Int, intensity: Int, sleep: Boolean) {
        val intent = Intent("com.snakesan.neonflux.REMOTE_CONFIG")
        intent.putExtra("profile", profile)
        intent.putExtra("bpm", bpm)
        intent.putExtra("intensity", intensity)
        intent.putExtra("sleep", sleep)
        intent.setPackage(packageName)
        sendBroadcast(intent)
    }

    // --- CONTROL METHODS ---
    
    // NEW: Called by UI "INITIALIZE" button to start EVERYTHING
    fun broadcastStartToPhone(bpm: Int, intensity: Int, profile: Int) {
        // 1. Calculate future start time for sync (e.g. 500ms from now)
        val targetTime = System.currentTimeMillis() + 500
        
        // 2. Start Local Engine (Delayed)
        startClinicalWithDelay(bpm, intensity, profile, targetTime)
        
        // 3. Send Message to Phone
        Wearable.getNodeClient(this).connectedNodes.addOnSuccessListener { nodes ->
            if (nodes.isEmpty()) return@addOnSuccessListener
            
            // Payload: [Profile, BPM, Intensity, Sleep(unused), TargetTime]
            val buffer = ByteBuffer.allocate(15)
            buffer.put(profile.toByte())
            buffer.putInt(bpm)
            buffer.put(intensity.toByte())
            buffer.put(0.toByte()) // Sleep flag not relevant for phone
            buffer.putLong(targetTime)
            
            val payload = buffer.array()
            
            nodes.forEach { node ->
                Wearable.getMessageClient(this).sendMessage(node.id, "/clinical_engage", payload)
            }
        }
    }
    
    // NEW: Called by UI "Crash" gesture to stop EVERYTHING
    fun broadcastStopToPhone() {
        Wearable.getNodeClient(this).connectedNodes.addOnSuccessListener { nodes ->
            nodes.forEach { node ->
                Wearable.getMessageClient(this).sendMessage(node.id, "/clinical_stop", byteArrayOf())
            }
        }
        haltLoops()
    }

    fun setReactorMode(audioEnabled: Boolean, profile: Int) {
        clinicalJob?.cancel()
        isRunning = true
        activeProfile = profile
        synth.start()
        val modeStr = if (audioEnabled) "REACTOR (AUDIO)" else "REACTOR (SILENT)"
        updateState(modeStr)
        scope.launch { reactorLoop(audioEnabled, profile) }
    }
    
    // Remote Start from Phone (Delayed for Sync)
    private fun startClinicalWithDelay(bpm: Int, intensity: Int, profile: Int, targetTime: Long) {
        clinicalJob?.cancel()
        isRunning = true
        activeProfile = profile
        synth.stop()
        updateState("CLINICAL ($bpm BPM)")

        clinicalJob = scope.launch {
            // Wait for sync time
            val wait = targetTime - System.currentTimeMillis()
            if (wait > 0) delay(wait)

            // NEW: Route to custom sequencer if Profile 3
            if (profile == 3) {
                cyberSequencerLoop(bpm, intensity)
            } else {
                clinicalLoop(bpm, intensity, profile)
            }
        }
    }

    fun haltLoops() {
        isRunning = false
        clinicalJob?.cancel()
        synth.isStandby = true
        synth.update()
        vibrator.cancel()

        // Notify Phone UI to clear Emergency State
        Wearable.getNodeClient(this).connectedNodes.addOnSuccessListener { nodes ->
            nodes.forEach { node ->
                Wearable.getMessageClient(this).sendMessage(node.id, "/emergency_halt", byteArrayOf())
            }
        }

        updateState("STANDBY")
    }

    fun haltService() {
        isRunning = false
        clinicalJob?.cancel()
        synth.stop()
        updateState("STANDBY")
        if (wakeLock?.isHeld == true) wakeLock?.release()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    // --- STATE PUBLISHER ---
    private fun updateState(modeText: String) {
        if (currentMode == modeText) return
        currentMode = modeText
        
        // 1. Broadcast to Overseer (Legacy Bridge)
        val overseerIntent = Intent("com.snakesan.overseer.UPDATE_STATUS")
        overseerIntent.setPackage("com.snakesan.overseer")
        overseerIntent.putExtra("source_app", "FLUX")
        overseerIntent.putExtra("flux_mode", modeText)
        overseerIntent.putExtra("is_active", isRunning)
        sendBroadcast(overseerIntent)

        // 2. Broadcast to Local UI
        val localIntent = Intent("com.snakesan.neonflux.STATE_CHANGE")
        localIntent.putExtra("mode", modeText)
        sendBroadcast(localIntent)

        // 3. Update Data Layer (Persistence)
        scope.launch {
            try {
                val putDataReq = PutDataMapRequest.create("/flux_status").apply {
                    dataMap.putString("flux_mode", modeText)
                    dataMap.putLong("timestamp", System.currentTimeMillis()) 
                }
                Wearable.getDataClient(this@FluxService).putDataItem(putDataReq.asPutDataRequest().setUrgent())
            } catch (e: Exception) { e.printStackTrace() }
        }
    }

    // --- ENGINES ---
    
    private suspend fun reactorLoop(audioEnabled: Boolean, profile: Int) {
        var lastNetSend = 0L
        
        // Get Phone Nodes
        var phoneNodes = emptyList<String>()
        Wearable.getNodeClient(this).connectedNodes.addOnSuccessListener { nodes -> phoneNodes = nodes.map { it.id } }

        while (isRunning) {
            val rawMag = synth.getSensorMagnitude()
            val intensity = (rawMag / 8.0f).coerceIn(0f, 1f)

            if (audioEnabled) {
                synth.amplitude = 0.2 + (intensity * 0.6)
                synth.isStandby = false
            } else {
                synth.isStandby = true
            }
            synth.update()

            // TELEMETRY TO PHONE
            val now = System.currentTimeMillis()
            if (now - lastNetSend > 100 && intensity > 0.1f) {
                if (phoneNodes.isNotEmpty()) {
                    val modeByte = if (audioEnabled) 3.toByte() else 1.toByte()
                    val intensityByte = (intensity * 100).toInt().toByte()
                    val payload = byteArrayOf(modeByte, 0, intensityByte)
                    phoneNodes.forEach { nodeId -> Wearable.getMessageClient(this@FluxService).sendMessage(nodeId, "/flux_sync", payload) }
                    lastNetSend = now
                } else if (now % 5000 < 100) {
                     Wearable.getNodeClient(this).connectedNodes.addOnSuccessListener { nodes -> phoneNodes = nodes.map { it.id } }
                }
            }

            if (intensity > 0.05f) {
                 when (profile) {
                    0 -> { 
                        delay(60); val amp = (intensity * 200).toInt().coerceAtLeast(10)
                        if (vibrator.hasAmplitudeControl()) vibrator.vibrate(VibrationEffect.createOneShot(30, amp))
                        else vibrator.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK))
                    }
                    1 -> { 
                        if (Random.nextFloat() < (intensity * 0.45f)) { vibrator.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK)); delay(40) } 
                        else delay(30)
                    }
                    2 -> {
                        delay(60); val heavyInt = (intensity * 1.5f).coerceAtMost(1f)
                        val amp = (heavyInt * 255).toInt().coerceAtLeast(20)
                        if (vibrator.hasAmplitudeControl()) vibrator.vibrate(VibrationEffect.createOneShot(80, amp))
                        else vibrator.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_HEAVY_CLICK))
                    }
                }
            } else {
                delay(40)
            }
        }
    }

    private suspend fun cyberSequencerLoop(bpm: Int, baseIntensity: Int) {
        if (customSequence.isEmpty()) {
            Log.w("FluxService", "Cyber Sequencer engaged but sequence is empty!")
            return
        }

        // Divide by 2 to get exactly 1/8th note steps
        val stepPeriodMs = (60000.0 / bpm) / 2.0
        var totalStepsRun = 0L
        val startTime = System.currentTimeMillis()

        while (isRunning) {
            val stepIndex = (totalStepsRun % customSequence.size).toInt()
            val step = customSequence[stepIndex]

            // 0: OFF, 1: HIT, 2: HIT(Override), 3: SUSTAIN, 4: SUSTAIN(Override)
            val prevState = customSequence[(stepIndex - 1 + customSequence.size) % customSequence.size].state

            // A note starts if it's a HIT, OR if it's a SUSTAIN and the previous cell was OFF (0)
            val isStartOfNote = step.state == 1 || step.state == 2 ||
                    ((step.state == 3 || step.state == 4) && prevState == 0)

            if (isStartOfNote) {
                var totalDuration = if (step.state == 1 || step.state == 2) 40L else stepPeriodMs.toLong()

                // Look-ahead for chained SUSTAIN blocks
                var lookAheadIdx = (stepIndex + 1) % customSequence.size
                while ((customSequence[lookAheadIdx].state == 3 || customSequence[lookAheadIdx].state == 4) && lookAheadIdx != stepIndex) {
                    totalDuration += stepPeriodMs.toLong()
                    lookAheadIdx = (lookAheadIdx + 1) % customSequence.size
                }

                val activeIntensity = if (step.state == 2 || step.state == 4) step.overrideIntensity else baseIntensity

                // Fire Single Gapless Pulse
                if (vibrator.hasAmplitudeControl()) {
                    val amp = (activeIntensity / 100f * 255).toInt().coerceIn(10, 255)
                    vibrator.vibrate(VibrationEffect.createOneShot(totalDuration, amp))
                } else {
                    vibrator.vibrate(VibrationEffect.createOneShot(totalDuration, VibrationEffect.DEFAULT_AMPLITUDE))
                }
            }

            // Zero-Drift Metronome Advance
            totalStepsRun++
            val nextStepTime = startTime + (totalStepsRun * stepPeriodMs).toLong()
            val sleepTime = nextStepTime - System.currentTimeMillis()

            if (sleepTime > 0) delay(sleepTime)
        }
    }
    
    private suspend fun clinicalLoop(bpm: Int, intensity: Int, profile: Int) {
        val periodMs = 60000.0 / bpm
        var beatCount = 0L
        val startTime = System.currentTimeMillis()

        while (isRunning) {
            if (intensity > 0) {
                 val amp = (intensity / 100f * 255).toInt().coerceAtLeast(10)
                 if (vibrator.hasAmplitudeControl()) {
                    when(profile) {
                        0 -> vibrator.vibrate(VibrationEffect.createOneShot(50, amp))
                        1 -> vibrator.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_TICK))
                        2 -> vibrator.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 100), intArrayOf(0, amp), -1))
                    }
                } else vibrator.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK))
            }
            beatCount++
            val nextBeatTime = startTime + (beatCount * periodMs).toLong()
            val sleepTime = nextBeatTime - System.currentTimeMillis()
            if (sleepTime > 0) delay(sleepTime)
        }
    }

    override fun onDestroy() {
        try { unregisterReceiver(killReceiver) } catch (e: Exception) {}
        Wearable.getMessageClient(this).removeListener(this)
        isRunning = false
        synth.stop()
        if (wakeLock?.isHeld == true) wakeLock?.release()
        scope.cancel()
        super.onDestroy()
    }
    
    private fun vibrateAck() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            vibrator.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_DOUBLE_CLICK))
        } else {
            vibrator.vibrate(100)
        }
    }

    private fun createNotificationChannel() {
        val serviceChannel = NotificationChannel("FLUX_CHANNEL", "NeonFlux Core", NotificationManager.IMPORTANCE_LOW)
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(serviceChannel)
    }

    private fun createNotification(text: String): Notification {
        return Notification.Builder(this, "FLUX_CHANNEL")
            .setContentTitle("NeonFlux")
            .setContentText(text)
            .setSmallIcon(R.mipmap.ic_launcher)
            .build()
    }
}
